package com.edubridge.app1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineJobPortal1Application {

	public static void main(String[] args) {
		SpringApplication.run(OnlineJobPortal1Application.class, args);
	}

}

