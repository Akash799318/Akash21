export class JobCategory {
    categoryId: number
    jobCategory: string
}
