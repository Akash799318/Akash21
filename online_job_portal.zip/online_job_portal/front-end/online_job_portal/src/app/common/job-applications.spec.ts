import { JobApplications } from './job-applications';

describe('JobApplications', () => {
  it('should create an instance', () => {
    expect(new JobApplications()).toBeTruthy();
  });
});
