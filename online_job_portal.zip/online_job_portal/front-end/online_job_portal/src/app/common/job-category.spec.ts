import { JobCategory } from './job-category';

describe('Category', () => {
  it('should create an instance', () => {
    expect(new JobCategory()).toBeTruthy();
  });
});
